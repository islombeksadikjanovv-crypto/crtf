import React, { useState, useMemo } from 'react';
import { useCartStore } from '../../core/store/cartStore';
import { Search, SlidersHorizontal, ShoppingCart, Star, ArrowUpRight, ShieldCheck, Truck, RotateCcw, Sparkles, X, Check } from 'lucide-react';
import keyboard from '../../assets/rgb клава.webp';
import watch from '../../assets/watch.jpg';
import headphones from '../../assets/Наушники.jpg';
import backpack from '../../assets/рюкзак кожанный.jpg';
import bottle from '../../assets/супер шейкер.jpg';

const products = [
  { id: '1', name: 'Беспроводные наушники Pro', price: 450000, category: 'Электроника', rating: 4.8, stock_quantity: 25, image_url: headphones, badge: 'Хит продаж', oldPrice: 520000 },
  { id: '2', name: 'Смарт-часы X-Check', price: 980000, category: 'Электроника', rating: 4.5, stock_quantity: 7, image_url: watch, badge: 'Новинка' },
  { id: '3', name: 'Кожаный городской рюкзак', price: 320000, category: 'Аксессуары', rating: 4.9, stock_quantity: 15, image_url: backpack, badge: 'Выбор покупателей' },
  { id: '4', name: 'Спортивная бутылка для воды', price: 85000, category: 'Спорт', rating: 4.2, stock_quantity: 50, image_url: bottle },
  { id: '5', name: 'Механическая клавиатура RGB', price: 670000, category: 'Электроника', rating: 4.7, stock_quantity: 12, image_url: keyboard, badge: 'Для геймеров' },
];
const categories = [
  { name: 'Все товары', value: 'Все', icon: '✦' },
  { name: 'Электроника', value: 'Электроника', icon: '⌘' },
  { name: 'Аксессуары', value: 'Аксессуары', icon: '◇' },
  { name: 'Спорт и отдых', value: 'Спорт', icon: '↗' },
];

export const ProductList = () => {
  const addToCart = useCartStore((state) => state.addToCart);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Все');
  const [sortBy, setSortBy] = useState('default');
  const [addedId, setAddedId] = useState(null);

  const filteredProducts = useMemo(() => products.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (selectedCategory === 'Все' || p.category === selectedCategory)
  ).sort((a,b) => sortBy === 'price-asc' ? a.price-b.price : sortBy === 'price-desc' ? b.price-a.price : 0), [searchQuery, selectedCategory, sortBy]);

  const handleAdd = (product) => {
    addToCart(product);
    setAddedId(product.id);
    window.setTimeout(() => setAddedId((id) => id === product.id ? null : id), 1200);
  };
  const money = (price) => `${price.toLocaleString('ru-RU')} сум`;

  return (
    <div className="catalog-page">
      <section className="hero-section">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={14}/> УМНЫЕ ПОКУПКИ НАЧИНАЮТСЯ ЗДЕСЬ</div>
          <h1>Любимые вещи.<br/><span>Лучшие цены.</span></h1>
          <p>Находите то, что делает каждый день удобнее. Подобрали полезные товары для работы, отдыха и жизни.</p>
          <button className="hero-cta" onClick={() => document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' })}>Смотреть каталог <ArrowUpRight size={18}/></button>
          <div className="hero-social-proof"><div className="proof-avatars"><span>А</span><span>М</span><span>И</span></div><div><strong>Удобно каждый день</strong><small>Товары, которые выбирают</small></div></div>
        </div>
        <div className="hero-art" aria-label="Подборка популярных товаров">
          <div className="hero-orbit orbit-one"/><div className="hero-orbit orbit-two"/>
          <div className="hero-sticker"><span>✨</span><strong>Good<br/>things.</strong></div>
          <div className="hero-product hero-product-main"><img src={headphones} alt="Беспроводные наушники"/><span>TOP PICK</span></div>
          <div className="hero-product hero-product-small"><img src={watch} alt="Смарт-часы"/></div>
          <div className="hero-product hero-product-bottom"><img src={keyboard} alt="RGB клавиатура"/></div>
          <div className="hero-floating-tag"><Star size={14} fill="currentColor"/> Выбор недели</div>
        </div>
        <div className="hero-index">01 <span/> 05</div>
      </section>

      <section className="benefits-strip">
        <div className="benefit"><span className="benefit-icon"><Truck size={20}/></span><div><strong>Быстрая доставка</strong><small>Без лишнего ожидания</small></div></div>
        <div className="benefit"><span className="benefit-icon"><ShieldCheck size={20}/></span><div><strong>Надёжный выбор</strong><small>Качество в приоритете</small></div></div>
        <div className="benefit"><span className="benefit-icon"><RotateCcw size={20}/></span><div><strong>Простой возврат</strong><small>Покупайте спокойно</small></div></div>
      </section>

      <section className="catalog-section" id="catalog">
        <div className="section-heading"><div><div className="section-kicker">НАШ ВЫБОР</div><h2>Найдите своё <span>любимое.</span></h2><p>Практичные вещи, которые стоят внимания.</p></div><div className="product-total"><strong>{filteredProducts.length.toString().padStart(2,'0')}</strong><span>товаров</span></div></div>
        <div className="catalog-toolbar">
          <div className="search-box"><Search size={19}/><input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Что ищем сегодня?"/>{searchQuery && <button onClick={() => setSearchQuery('')} aria-label="Очистить"><X size={16}/></button>}<kbd>⌕</kbd></div>
          <label className="sort-box"><SlidersHorizontal size={17}/><span>Сортировка</span><select value={sortBy} onChange={(e) => setSortBy(e.target.value)}><option value="default">По умолчанию</option><option value="price-asc">Сначала дешевле</option><option value="price-desc">Сначала дороже</option></select></label>
        </div>
        <div className="category-row">{categories.map((cat) => <button key={cat.value} onClick={() => setSelectedCategory(cat.value)} className={`category-pill ${selectedCategory === cat.value ? 'selected' : ''}`}><span>{cat.icon}</span>{cat.name}</button>)}</div>
        {filteredProducts.length === 0 ? <div className="empty-state"><span>⌕</span><h3>Ничего не нашлось</h3><p>Попробуйте изменить запрос или выбрать другую категорию.</p><button onClick={() => {setSearchQuery('');setSelectedCategory('Все')}}>Сбросить фильтры</button></div> :
          <div className="product-grid">{filteredProducts.map((product, index) => <article key={product.id} className="product-card" style={{'--card-index': index}}>
            <div className="product-image-wrap"><img src={product.image_url} alt={product.name} className="product-image"/>{product.badge && <span className={`product-badge ${product.id === '1' ? 'badge-hot' : ''}`}>{product.badge}</span>}<button className={`quick-add ${addedId === product.id ? 'added' : ''}`} onClick={() => handleAdd(product)} aria-label="Добавить в корзину">{addedId === product.id ? <Check size={19}/> : <ShoppingCart size={19}/>}</button></div>
            <div className="product-info"><div className="product-meta"><span>{product.category}</span><span className="rating"><Star size={13} fill="currentColor"/>{product.rating}</span></div><h3>{product.name}</h3><div className="stock-line"><span className="stock-dot"/>{product.stock_quantity > 10 ? 'В наличии' : `Осталось ${product.stock_quantity} шт.`}</div><div className="product-price-row"><div><strong>{money(product.price)}</strong>{product.oldPrice && <del>{money(product.oldPrice)}</del>}</div><button className={`add-button ${addedId === product.id ? 'added' : ''}`} onClick={() => handleAdd(product)}>{addedId === product.id ? <><Check size={15}/> Добавлено</> : 'В корзину'}</button></div></div>
          </article>)}</div>}
        <div className="catalog-note"><span><ShieldCheck size={16}/> Безопасные покупки</span><span>Новые находки появляются регулярно <span className="note-arrow">↗</span></span></div>
      </section>
    </div>
  );
};
