import React, { useState } from 'react';
import { ProductList } from './features/catalog/ProductList';
import { Login } from './features/auth/Login';
import { Register } from './features/auth/Register';
import { AdminDashboard } from './features/admin-dash/AdminDashboard';
import { SellerDashboard } from './features/seller-dash/SellerDashboard';
import { LogOut, ShieldCheck, Store, ShoppingBag, Menu, X, UserRound } from 'lucide-react';
import { useCartStore } from './core/store/cartStore';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('catalog');
  const [currentUser, setCurrentUser] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const cartItems = useCartStore((state) => state.cartItems);
  const cartCount = cartItems.reduce((sum, item) => sum + (item.quantity || 1), 0);

  const handleLoginSuccess = (user) => {
    setCurrentUser(user);
    setCurrentScreen(user.role === 'admin' ? 'admin' : user.role === 'seller' ? 'seller' : 'catalog');
  };
  const handleLogout = () => {
    localStorage.removeItem('token');
    setCurrentUser(null);
    setCurrentScreen('catalog');
  };
  const go = (screen) => { setCurrentScreen(screen); setMobileOpen(false); };

  return (
    <div className="app-shell">
      <div className="announcement"><span>✦</span> Yangi mavsum — yangi topilmalar <span className="announcement-link" onClick={() => go('catalog')}>Kashf eting <span>→</span></span></div>
      <header className="site-header">
        <div className="nav-wrap">
          <button className="brand" onClick={() => go('catalog')} aria-label="Bosh sahifa">
            <span className="brand-mark"><ShoppingBag size={21} strokeWidth={2.4}/></span>
            <span>mini<span className="brand-accent">market</span><small>SMART SHOPPING</small></span>
          </button>
          <nav className={`desktop-nav ${mobileOpen ? 'nav-open' : ''}`}>
            <button className={currentScreen === 'catalog' ? 'nav-link active' : 'nav-link'} onClick={() => go('catalog')}>Bosh sahifa</button>
            <button className="nav-link" onClick={() => go('catalog')}>Katalog</button>
            <button className="nav-link" onClick={() => go('catalog')}>Chegirmalar <span className="nav-new">HOT</span></button>
          </nav>
          <div className="nav-actions">
            <button className="icon-action cart-action" onClick={() => go('catalog')} aria-label="Savatcha">
              <ShoppingBag size={20}/><span className="cart-count">{cartCount}</span>
            </button>
            {currentUser ? (
              <div className="user-chip">
                {currentUser.role === 'admin' && <button className="role-action admin-action" onClick={() => go('admin')}><ShieldCheck size={15}/> Admin</button>}
                {currentUser.role === 'seller' && <button className="role-action seller-action" onClick={() => go('seller')}><Store size={15}/> Do‘konim</button>}
                <span className="user-avatar"><UserRound size={17}/></span>
                <span className="user-name">{currentUser.name}</span>
                <button className="icon-action logout-action" onClick={handleLogout} title="Chiqish"><LogOut size={17}/></button>
              </div>
            ) : <button className="login-button" onClick={() => go('login')}>Kirish <span>↗</span></button>}
            <button className="mobile-menu" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Menyu">{mobileOpen ? <X/> : <Menu/>}</button>
          </div>
        </div>
      </header>
      <main className="main-content">
        {currentScreen === 'catalog' && <ProductList />}
        {currentScreen === 'login' && <Login onNavigateToRegister={() => go('register')} onLoginSuccess={handleLoginSuccess}/>}
        {currentScreen === 'register' && <Register onNavigateToLogin={() => go('login')}/>}
        {currentScreen === 'admin' && <AdminDashboard />}
        {currentScreen === 'seller' && <SellerDashboard />}
      </main>
      <footer className="site-footer">
        <div className="footer-top"><div className="brand footer-brand"><span className="brand-mark"><ShoppingBag size={20}/></span><span>mini<span className="brand-accent">market</span><small>SMART SHOPPING</small></span></div><p>Har kuni kerakli narsalar. Bir joyda.</p></div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} MiniMarket. Barcha huquqlar himoyalangan.</span><span className="footer-status"><i/> Siz uchun qulay xarid</span></div>
      </footer>
    </div>
  );
}
