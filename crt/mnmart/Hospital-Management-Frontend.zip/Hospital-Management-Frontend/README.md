# CarePoint — Hospital Management Frontend

A responsive React + Vite frontend designed to work with the supplied Hospital Management Server.

## Requirements
- Node.js 20+ recommended
- The provided backend running on `http://localhost:5089`
- PostgreSQL configured and seeded according to the backend README/configuration

## Run
```bash
npm install
cp .env.example .env
npm run dev
```
Open the URL Vite prints (usually `http://localhost:5173`).

On Windows PowerShell, if you do not have `cp`, simply copy `.env.example` to `.env` using File Explorer. Change `VITE_API_URL` if your backend uses a different address.

## Demo users
The server's seed script defines these demo users (password: `password123`):
- Admin: `admin@clinic.com`
- Doctor: `doctor@clinic.com`
- Patient: `patient@clinic.com`
- Receptionist: `receptionist@clinic.com`

These accounts are only available if the backend database has actually been seeded.

## Implemented screens
- Sign in and patient registration
- Role-aware dashboard for Patient, Doctor, Receptionist, and Admin
- Doctor directory and admin add-doctor form
- Patient appointment booking with available-slot lookup
- Appointment lists and status updates
- Receptionist schedule calendar
- Responsive layout, loading/error states, toasts, and mobile navigation

## API integration
Defaults to `http://localhost:5089/api` and uses the bearer token returned by `POST /auth/login`.
The UI calls the routes defined in `src/app.js` of the provided backend.

## Notes about the supplied backend
- Department selection in Add Doctor uses IDs 1–4 from the included seed script. Verify these IDs in your database before creating staff.
- The server's login endpoint requires a role; the sign-in form includes it.
- Some backend endpoints in the supplied code may not enforce role-based access control. Frontend role-aware navigation is not a security boundary; protect sensitive routes on the server before production use.
- The provided server contains no departments endpoint or medical-record creation route registered in `src/app.js`; the frontend does not assume either endpoint exists.
